#! /bin/bash

rm -f run.mysql.tests.bash

wget https://github.com/Tokutek/ft-engine/raw/master/scripts/run.mysql.tests.bash

chmod 755 run.mysql.tests.bash
