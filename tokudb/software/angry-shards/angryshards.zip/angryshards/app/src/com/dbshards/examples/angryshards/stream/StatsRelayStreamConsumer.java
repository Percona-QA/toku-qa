package com.dbshards.examples.angryshards.stream;

import com.codefutures.common.jdbc.ConnectionPool;
import com.codefutures.common.jdbc.ConnectionPoolConfig;
import com.codefutures.common.jdbc.ConnectionPoolImpl;
import com.codefutures.common.logging.Logger;
import com.codefutures.common.logging.LoggerFactory;
import com.codefutures.common.util.Sleep;
import com.dbshards.agent.stream.StreamConsumer;
import com.dbshards.config.api.IDbShardsConfig;
import com.dbshards.sqlparsernew.DbsStatement;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Copyright (C) 2011 CodeFutures Corporation. All rights reserved.
 */
public class StatsRelayStreamConsumer implements StreamConsumer {

    private static final Logger logger = LoggerFactory.getLogger(StatsRelayStreamConsumer.class);

    private static final boolean TRACE = logger.isTraceEnabled();

    private ConnectionPool connectionPool;

    private final Map<String, StatsRelayDBWriter> dbWriterMap = new HashMap<String,StatsRelayDBWriter>();

    private static final Executor commitExec = Executors.newSingleThreadExecutor();

    private int targetBatchSize = 100;
    
    private int targetPShardCount = 1;
    
    // The maximum length in ms for each batch if the targetBatchSize is not reached. Default 10s.
    private int targetBatchInterval = 10 * 1000;

    @Override
    public void init(IDbShardsConfig dbShardsConfig, Properties pluginProperties) {

        final ConnectionPoolConfig config = new ConnectionPoolConfig();
        final Properties prop = new Properties();

        final String jdbcDriver   = pluginProperties.getProperty("target.jdbc.driver");
        final String jdbcUrl      = pluginProperties.getProperty("target.jdbc.url");
        final String jdbcUser     = pluginProperties.getProperty("target.jdbc.user");
        final String jdbcPassword = pluginProperties.getProperty("target.jdbc.pass");
        final String strTargetBatchSize = pluginProperties.getProperty("target.batch.size");
        final String strTargetPShardCount = pluginProperties.getProperty("target.pshard.count");
        final String strTargetBatchInterval = pluginProperties.getProperty("target.batch.interval");

        if (strTargetBatchSize != null) {
            targetBatchSize = Integer.parseInt(strTargetBatchSize);
        }
        
        if(strTargetPShardCount == null) {
        	throw new RuntimeException("The target.pshard.count property is required.");
        }
        targetPShardCount = Integer.parseInt(strTargetPShardCount);

        if(strTargetBatchInterval != null && strTargetBatchInterval.length() > 0) {
        	targetBatchInterval = Integer.parseInt(strTargetBatchInterval) * 1000;
        }

        try {
            logger.error("Initializing JDBC driver " + jdbcDriver);
            Class.forName(jdbcDriver);
        } catch (ClassNotFoundException e) {
            logger.error("Failed to initialize JDBC driver " + jdbcDriver, e);
        }

        config.setDriverClass(jdbcDriver);
        config.setUrl(jdbcUrl);
        prop.setProperty("user", jdbcUser);
        prop.setProperty("password", jdbcPassword);

        config.setProp(prop);
        
        this.connectionPool = new ConnectionPoolImpl(config, "MonetDBPool");

        commitExec.execute(new Runnable() {
            public void run() {
                while (true) {
                    Sleep.ms(targetBatchInterval);
                    flushAllWriters();
                }
            }
        });
        
        logger.info("Running with: "
        		+ " target.jdbc.driver: " + jdbcDriver
        		+ " target.jdbc.url: " + jdbcUrl
        		+ " target.jdbc.user: " + jdbcUser
        		+ " target.batch.size: " + strTargetBatchSize
        		+ " target.batch.interval: " + targetBatchInterval
        		+ " target.pshard.count: " + targetPShardCount);
    }

    @Override
    public String getFilenameSuffix() {
        return "-angryshards";
    }

    @Override
    public void begin(String connectionID, long txID) {
    	// Empty.
    }

    @Override
    public void process(int stmtId, DbsStatement sqlStatement) {

        if (TRACE) logger.trace("process(stmtID: " + stmtId + ", sql: " + sqlStatement.getSQL());

        if (!sqlStatement.getSymbolTable().isInsert()) {
            // Ignore non-INSERT SQL.
            if (TRACE) logger.trace("Ignoring non-INSERT SQL: " + sqlStatement.getSQL());
            return;
        }

        if (sqlStatement.getTableList().size()==0) {
            if (TRACE) logger.trace("Ignoring SQL with no table name: " + sqlStatement.getSQL());
            return;
        }

        final String tableName = sqlStatement.getTableList().get(0);

        // Handle only the player_stat table.
        if (tableName.equalsIgnoreCase("player_stat")) {

            StatsRelayDBWriter writer = null;
            synchronized (dbWriterMap) {
                writer = dbWriterMap.get(tableName);
                if (writer==null) {
                    logger.info("Creating new DBWriter for " + tableName);
                    writer = new StatsRelayDBWriter(connectionPool, targetBatchSize, targetPShardCount, sqlStatement);
                    dbWriterMap.put(tableName, writer);
                }
            }

            // Send sqlStatement to writer.
            try {
                writer.execute(sqlStatement);
            } catch (Throwable e) {
                logger.error("Failed to execute: " + sqlStatement.getSQL(), e);

                // re-throw the exception so that the stream agent pauses
                throw new RuntimeException(e);
            }
        }
        else {
            if (TRACE) {
                logger.trace("Ignoring SQL " + sqlStatement.getSQL());
            }
        }

    }

    @Override
    public void commit() {
    }

    public void flushAllWriters() {
        synchronized (dbWriterMap) {
            for (StatsRelayDBWriter writer : dbWriterMap.values()) {
                try {
                    writer.commit();
                } catch (Throwable e) {
                    logger.error("Failed to flush writer", e);
                }
            }
        }
    }
}
