package com.dbshards.examples.angryshards.stream;

import com.codefutures.common.jdbc.ConnectionPool;
import com.codefutures.common.jdbc.ConnectionPoolConfig;
import com.codefutures.common.jdbc.ConnectionPoolImpl;
import com.codefutures.common.logging.Logger;
import com.codefutures.common.logging.LoggerFactory;
import com.dbshards.agent.stream.StreamConsumer;
import com.dbshards.config.api.IDbShardsConfig;
import com.dbshards.sqlparsernew.DbsStatement;
import com.dbshards.sqlparsernew.DbsValueExpression;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Properties;

/**
 * Copyright (C) 2011 CodeFutures Corporation. All rights reserved.
 */
public class AngryShardsStreamConsumer implements StreamConsumer {

    private static final Logger logger = LoggerFactory.getLogger(AngryShardsStreamConsumer.class);

    private ConnectionPool connectionPool;

    private Connection conn;

    @Override
    public void init(IDbShardsConfig dbShardsConfig, Properties pluginProperties) {

        final ConnectionPoolConfig config = new ConnectionPoolConfig();
        final Properties prop = new Properties();

        final String jdbcDriver   = pluginProperties.getProperty("target.jdbc.driver"); // "nl.cwi.monetdb.jdbc.MonetDriver";
        final String jdbcUrl      = pluginProperties.getProperty("target.jdbc.url");    //"jdbc:monetdb://SERVER:54321/angryshards";
        final String jdbcUser     = pluginProperties.getProperty("target.jdbc.user");   //"monetdb";
        final String jdbcPassword = pluginProperties.getProperty("target.jdbc.pass");   //"monetdb";

        try {
            logger.error("Initializing JDBC driver " + jdbcDriver);
            Class.forName(jdbcDriver);
        } catch (ClassNotFoundException e) {
            logger.error("Failed to initialize JDBC driver " + jdbcDriver, e);
        }

        config.setDriverClass(jdbcDriver);
        config.setUrl(jdbcUrl);
        prop.setProperty("user", jdbcUser);
        prop.setProperty("password", jdbcPassword);

        config.setProp(prop);

        this.connectionPool = new ConnectionPoolImpl(config, "MonetDBPool");
    }

    @Override
    public String getFilenameSuffix() {
        return "angryshards";
    }

    @Override
    public void begin(String connectionID, long txID) {
    }

    @Override
    public void process(int stmtId, DbsStatement sqlStatement) {
        logger.info("process() " + sqlStatement.getSQL());

        // determine if we want to replicate this statement to MonetDB or not
        boolean replicate = false;
        if (sqlStatement.getTableList().size()>0 && sqlStatement.getTableList().get(0).equalsIgnoreCase("player_stat")) {
            replicate = true;
        }

        if (replicate) {

            try {
                if (conn == null) {
                    conn = connectionPool.borrowConnection();
                }

                PreparedStatement pstmt = conn.prepareStatement(sqlStatement.getSQL());
                List<DbsValueExpression> boundParam = sqlStatement.getValueList();
                if (boundParam != null) {
                    for (int i=0; i<boundParam.size(); i++) {
                        final Object value = boundParam.get(i).getLiteralValue();
                        pstmt.setObject(i+1, value);
                    }
                }

                int rows = pstmt.executeUpdate();
            }
            catch (SQLException sqle) {
                throw new RuntimeException(sqle);
            }

        }
    }

    @Override
    public void commit() {
        if (conn != null) {
            try {
                conn.commit();
            }
            catch (SQLException sqle) {
                throw new RuntimeException(sqle);
            }
            finally {
                connectionPool.returnConnection(conn);
                conn = null;
            }
        }
    }
}
