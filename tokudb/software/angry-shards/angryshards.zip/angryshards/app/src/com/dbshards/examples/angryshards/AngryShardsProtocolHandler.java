package com.dbshards.examples.angryshards;

import com.codefutures.common.logging.Logger;
import com.codefutures.common.logging.LoggerFactory;
import com.codefutures.nio.NioByteBuffer;
import com.codefutures.nio.NioConnection;
import com.codefutures.nio.NioProtocolHandler;
import com.codefutures.nio.NioResponseWriter;
import com.codefutures.protobuf.CFProtocolHelper;

import java.io.IOException;
import java.nio.channels.SocketChannel;

/**
 * Copyright (C) 2011 CodeFutures Corporation. All rights reserved.
 */
public class AngryShardsProtocolHandler implements NioProtocolHandler {

    private static final Logger logger = LoggerFactory.getLogger(AngryShardsProtocolHandler.class);

    @Override
    public void newConnection(NioConnection nioConnection, SocketChannel socketChannel) throws Exception {
    }

    @Override
    public void connectionClosed(NioConnection nioConnection) throws Exception {
    }

    @Override
    public boolean processBuffer(final NioConnection nioConnection,
                                 final NioByteBuffer byteBuffer,
                                 final NioResponseWriter nioResponseWriter) throws Exception {
        boolean ret = false;

        // process all available messages in the buffer
        while (byteBuffer.getIndex() >= 4) {

            final byte messageBytes[] = byteBuffer.getBuffer();

            // get message length (sfixed32)
            final int messageLength = CFProtocolHelper.readInt(messageBytes);

            logger.trace("messageLength = " + messageLength);

            if (messageLength<0) {
                // not enough bytes available to read the varint that indicates the message length
                break;
            }

            // do we have at least one complete message?
            final int startOfNextMessage = 4 + messageLength;
            if (byteBuffer.getIndex() >= messageLength) {

                // return true because there was at least one complete message
                ret = true;

                // process the message
                try {

                    byte singleMessageBytes[] = new byte[messageLength];
                    System.arraycopy(messageBytes, 4, singleMessageBytes, 0, messageLength);

                    //TODO: implement code here to call generated code to decode the message


                } catch (Throwable th) {
                    throw new IOException("Failed to process message", th);
                } finally {
                    byteBuffer.deleteBefore(startOfNextMessage);
                }

            } else {
                // we have a partial message, so we quit and go back to the loop that is reading from the socket
                break;
            }
        }

        return ret;
    }
}
