package com.dbshards.examples.angryshards.service;

import com.codefutures.common.jdbc.ConnectionPool;
import com.codefutures.common.logging.Logger;
import com.codefutures.common.logging.LoggerFactory;
import com.dbshards.jdbc.DbsConnection;

import java.math.BigDecimal;
import java.sql.*;

/**
 * Copyright (C) 2011 CodeFutures Corporation. All rights reserved.
 */
public class AngryShardsService {

    private static final Logger logger = LoggerFactory.getLogger(AngryShardsService.class);

    private ConnectionPool connectionPool;

    public AngryShardsService(ConnectionPool connectionPool) {
        this.connectionPool = connectionPool;
    }

    public int findGame(final String gameName) throws SQLException {

        final String sql = "SELECT game_id FROM game WHERE game_name = ?";

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int gameId = -1;

        try {

            conn = connectionPool.borrowConnection();

            pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, gameName);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                gameId = rs.getInt(1);
            }

            conn.commit();

        } finally {
            cleanup(conn, pstmt, rs);
        }

        return gameId;
    }

    public int createGame(final String gameName) throws SQLException {

        final String sql = "INSERT INTO game (game_name) VALUES (?)";

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int gameId = -1;

        try {

            conn = connectionPool.borrowConnection();

            pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, gameName);
            pstmt.executeUpdate();

            gameId = getAutoIncrementId(pstmt);

            conn.commit();

        } finally {
            cleanup(conn, pstmt, rs);
            conn = null;
            pstmt = null;
            rs = null;
        }

        return gameId;
    }

    /**
     * Create a new player with a zero balance.
     *
     * @param playerEmail
     * @param screenName
     * @throws SQLException
     */
    public int registerPlayer(final String playerEmail, final String screenName, final String password) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int playerId = -1;
        int playerAuthId = -1;

        try {

            conn = connectionPool.borrowConnection();

            pstmt = conn.prepareStatement("INSERT INTO player (player_email, screen_name, player_balance) VALUES (?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, playerEmail);
            pstmt.setString(2, screenName);
            pstmt.setBigDecimal(3, new BigDecimal(0));
            pstmt.executeUpdate();
            playerId = getAutoIncrementId(pstmt);
            pstmt.close();

            pstmt = conn.prepareStatement("INSERT INTO player_auth (auth_type_code, auth_id, player_id, password) VALUES (?, ?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, 10); // auth_type_code
            pstmt.setString(2, playerEmail); // auth_id
            pstmt.setInt(3, playerId);
            pstmt.setString(4, password);
            pstmt.executeUpdate();
            playerAuthId = getAutoIncrementId(pstmt);
            pstmt.close();

            conn.commit();

        } finally {
            cleanup(conn, pstmt, rs);
            conn = null;
            pstmt = null;
            rs = null;
        }

        // second transaction - player_lookup is in a separate shard tree - this could all be part of one
        // transaction as a multi-shard-update but this is slightly more efficient
        try {

            conn = connectionPool.borrowConnection();

            pstmt = conn.prepareStatement("INSERT INTO player_lookup (player_auth_id, player_id, auth_id) VALUES (?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, playerAuthId);
            pstmt.setInt(2, playerId);
            pstmt.setString(3, playerEmail);
            pstmt.executeUpdate();
            pstmt.close();

            conn.commit();

        } finally {
            cleanup(conn, pstmt, rs);
            conn = null;
            pstmt = null;
            rs = null;
        }

        return playerId;
    }

    public int loginPlayer(final String playerEmail, final String password) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int playerId = -1;
        int playerAuthId = -1;
        boolean loginSuccess = false;

        // transaction 1 - lookup in player_lookup
        try {

            conn = connectionPool.borrowConnection();

            pstmt = conn.prepareStatement("SELECT player_id, player_auth_id FROM player_lookup WHERE auth_id = ?");
            pstmt.setString(1, playerEmail);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                playerId = rs.getInt(1);
                playerAuthId = rs.getInt(2);
            }
            rs.close();
            pstmt.close();


        } finally {
            cleanup(conn, pstmt, rs);
            conn = null;
            pstmt = null;
            rs = null;
        }

        if (playerId != -1 && playerAuthId != -1) {

            // transaction two - authenticate user
            try {

                conn = connectionPool.borrowConnection();

                pstmt = conn.prepareStatement("SELECT 1 FROM player_auth WHERE player_auth_id = ? AND player_id = ?");
                pstmt.setInt(1, playerAuthId);
                pstmt.setInt(2, playerId);
                rs = pstmt.executeQuery();
                if (rs.next()) {
                    loginSuccess = true;
                }
                rs.close();
                pstmt.close();


            } finally {
                cleanup(conn, pstmt, rs);
                conn = null;
                pstmt = null;
                rs = null;
            }
        }

        if (!loginSuccess) {
            throw new RuntimeException("No player found for given email address and password combination");
        }

        return playerId;
    }

    public int findRandomOpponent(int currentPlayerId) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int playerId = -1;

        try {

            conn = connectionPool.borrowConnection();

            String sql = "SELECT player_id FROM player WHERE player_id != ? ORDER BY rand() LIMIT 1";

            if (conn instanceof DbsConnection) {
                // if we are using dbShards then run this query against a random shard rather than performing
                // a Go Fish query
                DbsConnection dbsConn = (DbsConnection) conn;
                final int numPhysicalShards = dbsConn.getNumPhysicalShards();
                int randomShard = (int) (1 + ((Math.random()*1000) % numPhysicalShards));
                sql = "/*DBS_HINT: dbs_shard_action=shard_read, dbs_pshard=" + randomShard + " */ "+  sql;
            }

            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, currentPlayerId);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                playerId = rs.getInt(1);
            }
            rs.close();
            pstmt.close();

            conn.commit();

        } finally {
            cleanup(conn, pstmt, rs);
            conn = null;
            pstmt = null;
            rs = null;
        }

        if (playerId == -1) {
            throw new RuntimeException("Failed to find random opponent - database empty?");
        }

        return playerId;
    }

    public int savePlayerGame(final int gameId, final int playerId, final int playerScore[]) throws SQLException {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int playerGameId = -1;

        int totalScore = 0;
        for (Integer score : playerScore) {
            totalScore += score;
        }

        try {

            conn = connectionPool.borrowConnection();

            pstmt = conn.prepareStatement("INSERT INTO player_game (game_id, player_id, player_score) VALUES (?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, gameId);
            pstmt.setInt(2, playerId);
            pstmt.setInt(3, totalScore);
            pstmt.executeUpdate();
            playerGameId = getAutoIncrementId(pstmt);
            pstmt.close();

            /*
            pstmt = conn.prepareStatement(
                    "INSERT INTO player_game_opponent (" +
                            "player_game_opponent_id, player_game_id, player_friend_id, " +
                            "opponent_player_id, opponent_screen_name, opponent_score, " +
                            "challenge_message, status_code) " +
                    "VALUES (?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, );
            pstmt.executeUpdate();

            */

            pstmt = conn.prepareStatement("INSERT INTO player_game_round (player_game_id, player_id, player_score) VALUES (?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS);

            for (int round=1; round<=playerScore.length; round++) {
                //TODO: set 'round' column - to be added to schema
                pstmt.setInt(1, playerGameId);
                pstmt.setInt(2, playerId);
                pstmt.setInt(3, playerScore[round-1]);
                pstmt.executeUpdate();
            }

            //TODO:
            /*
            pstmt = conn.prepareStatement("INSERT INTO player_stat (player_id, stat_code, stat_value, stat_timestamp) VALUES (?, ?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS);
            // create some stats
            final long now = System.currentTimeMillis();
            for (int i=0; i<5; i++) {
                final int statCode = 10 + i;
                final int statValue = (int) (100 * Math.random());
                pstmt.setInt(1, playerId);
                pstmt.setInt(2, statCode);
                pstmt.setInt(3, statValue);
                pstmt.setTimestamp(4, new java.sql.Timestamp(now));
                pstmt.executeUpdate();
            }
            pstmt.close();
            */

            conn.commit();

        } finally {
            cleanup(conn, pstmt, rs);
            conn = null;
            pstmt = null;
            rs = null;
        }

        return playerGameId;
    }

    public void createStatCode(final int statCode, final String statName) throws SQLException {
        final String sql = "INSERT IGNORE INTO stat_code (stat_code, stat_name) VALUES (?, ?)";

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn = connectionPool.borrowConnection();

            pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, statCode);
            pstmt.setString(2, statName);
            pstmt.executeUpdate();

            conn.commit();

        } finally {
            cleanup(conn, pstmt, rs);
            conn = null;
            pstmt = null;
            rs = null;
        }
    }


    private int getAutoIncrementId(final Statement stmt) throws SQLException {
        ResultSet rs = null;
        try {
            rs = stmt.getGeneratedKeys();
            if (rs != null && rs.next()) {
                return rs.getInt(1);
            }
            else {
                throw new RuntimeException("Failed to fetch auto increment ID - getGeneratedKeys returned no rows");
            }
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    logger.error("Failed to close auto increment result set", e);
                }
            }
        }

    }
    /**
     * Close JDBC resources.
     *
     * @param conn
     * @param stmt
     * @param rs
     */
    private void cleanup(final Connection conn, final Statement stmt, final ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                logger.error("", e);
            }
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                logger.error("", e);
            }
        }
        if (conn != null) {
            connectionPool.returnConnection(conn);
        }
    }
}
