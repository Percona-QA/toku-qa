package com.dbshards.examples.angryshards.stream;

import com.codefutures.common.etl.ETLFactory;
import com.codefutures.common.etl.Field;
import com.codefutures.common.etl.Record;
import com.codefutures.common.logging.Logger;
import com.codefutures.common.logging.LoggerFactory;
import com.dbshards.agent.stream.StreamConsumer;
import com.dbshards.config.api.IDbShardsConfig;
import com.dbshards.config.api.IDbsDatabaseConfig;
import com.dbshards.config.api.IDbsDomainConfig;
import com.dbshards.config.api.IDbsTable;
import com.dbshards.config.domain.DbsConfigLoader;
import com.dbshards.sqlparsernew.DbsStatement;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import nl.cwi.monetdb.mcl.io.BufferedMCLReader;
import nl.cwi.monetdb.mcl.io.BufferedMCLWriter;
import nl.cwi.monetdb.mcl.net.MapiSocket;

/**
 * Copyright (C) 2012 Insomniac Games. All rights reserved.
 * 
 * This stream consumer is used to apply transactions
 * in batches directly to MonetDb. MonetDb functions very well with a single batch feed
 * using the COPY INTO SQL statement, writing delimited rows. The MonetDb tables are defined
 * as log-only tables, so that a MonetDb connection can be used directly
 * from stream consumers on both the Primary and Secondary servers for each shard. 
 * 
 * Each transaction is only for a single table, and can be applied in its entirety in a single
 * batch to MonetDb. 
 * 
 * JDBC is not used, rather the Monet API (MAPI) server is used directly, converting each SQL 
 * statement into an individual delimited row.
 * 
 * On receiving a commit, the connection to the MAPI server is closed, and on begin a new 
 * connection is opened.
 * 
 *  With MAPI a COPY INTO statement is sent first (from the begin), then each SQL statement
 *  is written as a delimited row with all columns for the target table. Since each incoming
 *  statement may only have some of the columns in the table, the delimited row must be 
 *  padded accordingly. 
 */
public class StatsApplierStreamConsumer implements StreamConsumer {

    private static final Logger logger = LoggerFactory.getLogger(StatsApplierStreamConsumer.class);
    private static final boolean TRACE = logger.isTraceEnabled();

    // Domain name param.
    private String domainName;
    
    // dbShards Config objects.
    IDbsDomainConfig domainConfig;
    IDbsDatabaseConfig databaseConfig;
    
    // MAPI connection params.
    private static final String MAPI_LANGUAGE = "sql";
    private String mapiHost;
    private int mapiPort;
    private String mapiDatabase;
    private String mapiSchema;
    private String mapiUser;
    private String mapiPassword;
    
    // List of delimited data row objects for the current transaction. This is for all INSERT statements
    // which are handled in a bulk load using the MonetDb native API.
	private List<String> dataRowList;
		
	// Only a single tableName is used for a transaction for INSERTs. The StatsRelayDBWriter ensures only
	// one table per transaction.
	private String tableName;
	
	// Record objects for each output table.
	private Record playerStatRecord;
	
	// Table column name maps of column name to 0-based index.
	private Map<String,Integer> playerStatColumnNameMap;
		
	// Stats counters.
	
	// Track the number of batches and total number of rows for an average batch size.
	private long insertBatchCounter = 0;
	private long insertRowCounter = 0;
	private long statsStartTime = System.currentTimeMillis();
	
	// Output stats, default to every 10 batches or every 10,000 rows.
	private int statsBatchLimit = 10;
	private int statsRowLimit = 10 * 1000;

	
	@Override
    public void init(IDbShardsConfig dbShardsConfig, Properties pluginProperties) {
		this.domainName = dbShardsConfig.getDomain();
		
		// Load the dbShards configs.
		try {
			domainConfig = DbsConfigLoader.loadDomainConfig(domainName);
			databaseConfig = DbsConfigLoader.loadDatabaseConfig(domainName);
			
		} catch(Throwable th) {
			throw new RuntimeException("Error loading config", th);
		}
		
		// Get the parameters for the MonetDb MAPI host connection.
        mapiHost = pluginProperties.getProperty("target.mapi.host");
        if(mapiHost == null || mapiHost.length() == 0) {
        	throw new ExceptionInInitializerError("The target.mapi.host property is required.");
        }
        final String mapiPortString = pluginProperties.getProperty("target.mapi.port");
        if(mapiPortString == null || mapiPortString.length() ==0) {
        	throw new ExceptionInInitializerError("The target.mapi.port property is required.");
        }
        mapiPort = Integer.parseInt(mapiPortString);
        mapiDatabase = pluginProperties.getProperty("target.mapi.database");
        if(mapiDatabase == null || mapiDatabase.length() == 0) {
        	throw new ExceptionInInitializerError("The target.mapi.database property is required.");
        }
        mapiSchema = pluginProperties.getProperty("target.mapi.schema");
        if(mapiSchema == null || mapiSchema.length() == 0) {
        	throw new ExceptionInInitializerError("The target.mapi.schema property is required.");
        }
        mapiUser = pluginProperties.getProperty("target.mapi.user");
        if(mapiUser == null || mapiUser.length() == 0) {
        	throw new ExceptionInInitializerError("The target.mapi.user property is required.");
        }
        mapiPassword = pluginProperties.getProperty("target.mapi.password");
        if(mapiPassword == null || mapiPassword.length() == 0) {
        	throw new ExceptionInInitializerError("The target.mapi.password property is required.");
        }
                
        final String strStatsBatchLimit = pluginProperties.getProperty("stats.batch.limit");
        if(strStatsBatchLimit != null && strStatsBatchLimit.length() > 0) {
        	statsBatchLimit = Integer.parseInt(strStatsBatchLimit);
        }
        
        final String strStatsRowLimit = pluginProperties.getProperty("stats.row.limit");
        if(strStatsRowLimit != null && strStatsRowLimit.length() > 0) {
        	statsRowLimit = Integer.parseInt(strStatsRowLimit);
        }
                
        // Init record objects.
        initRecordObjects();
        
        logger.info("Initializing StatsApplierStreamConsumer with: " 
        		+ " target.mapi.host: " + mapiHost
        		+ " target.mapi.port: " + mapiPort
        		+ " target.mapi.database: " + mapiDatabase
        		+ " target.mapi.schema: " + mapiSchema
        		+ " target.mapi.user: " + mapiUser
        		+ " stats.batch.limit: " + statsBatchLimit
        		+ " stats.row.limit: " + statsRowLimit);

    }

    /**
     * Initialize all Record objects for each table, with the correct number of fields
     * matching each target table. A single Record object for each table is re-used, 
     * avoiding excessive object creation.
     * 
     * NOTE: MonetDb is very exact in its handling of delimited rows. If it cannot recognize
     * a data type as matching that of a column, it stops counting fields and you get a
     * missing field message (e.g., expected n fields to y).
     */
    private void initRecordObjects() {
    	
        // Configure the ETL factory.
        ETLFactory.setDbms(ETLFactory.GENERIC);
            	
    	playerStatRecord = new Record();
    	IDbsTable dbsTable = databaseConfig.getDatabase().getTable("angryshards.player_stat");
    	playerStatColumnNameMap = new HashMap<String,Integer>();
    	
    			
    	for(int i=0;i<dbsTable.getColumnCount();i++) {
        	Field f = ETLFactory.createField();
    		playerStatRecord.setField(i, f);
    		
    		// Build the column names map.
    		playerStatColumnNameMap.put(dbsTable.getColumnList().get(i).getName(), i);
    	}
    	
     }
    
    /**
     * Set all Fields in record to NULL.
     * @param record
     */
    private void resetRecord(Record record) {
    	for(int i=0;i<record.getFieldCount();i++) {
    		record.getField(i).setNull();
    	}
    }
        
    @Override
	public String getFilenameSuffix() {
		return "-angryshards";
	}

	/**
     * For each incoming transaction, set up a connection to the server.
     */
    @Override
    public void begin(String connectionID, long txID) {

    	// Start a new list for the transaction for INSERTs.
    	dataRowList = new ArrayList<String>();   
    	
    	// Reset the tableName.
    	tableName = null;
    }

    @Override
    public void process(int stmtId, DbsStatement sqlStatement) {
    	
        if (TRACE) logger.trace("process: stmtId: " + stmtId + ", sql: " + sqlStatement.getSQL());

        if (!sqlStatement.getSymbolTable().isInsert()) {
            // ignore DDL
            if (TRACE) logger.trace("Ignoring non-INSERT SQL: " + sqlStatement.getSQL());
            return;
        }
        
        if (sqlStatement.getTableList().size()==0) {
            if (TRACE) logger.trace("Ignoring SQL with no table name: " + sqlStatement.getSQL());
            return;
        }

        final String statementTableName = sqlStatement.getTableList().get(0);
        
        // The first statement sets the table name. If it changes within an INSERT transaction, its an error.
        if(tableName == null) {
        	tableName = statementTableName;
        } else {
        	if(!tableName.equals(statementTableName) && sqlStatement.getSymbolTable().isInsert()) {
        		throw new RuntimeException("The tableName must remain the same for a single INSERT transaction. statementTableName: " 
        				+ statementTableName + " tableName: " + tableName);
        	}
        }

        // Only process player_stat table (there should not be any other tables).
        if (tableName.equalsIgnoreCase("player_stat")) {

        	// Add the statement to list.
        	final String dataRow = buildDataRow(sqlStatement);
        	dataRowList.add(dataRow);
            	

        }
        else {
            if (TRACE) {
                logger.trace("Ignoring SQL " + sqlStatement.getSQL());
            }
        }

    }

    /**
     * Commit the transaction. This is where all writes to MonetDb occur, using the MAPI API.
     * For UPDATE/DELETE statements, use JDBC with an explicit commit.
     * A new connection is made for each transaction, then it is closed.
     */
    @Override
    public void commit() {

    	// Write any INSERTs through the MAPI API.
		if (dataRowList.size() > 0) {
			MapiSocket server = new MapiSocket();
			server.setDatabase(mapiDatabase);
			server.setLanguage(MAPI_LANGUAGE);
			try {
				List<String> warning = server.connect(mapiHost, mapiPort,
						mapiUser, mapiPassword);
				if (warning != null) {
					for (Iterator<String> it = warning.iterator(); it.hasNext();) {
						logger.warn(it.next().toString());
					}
				}

				BufferedMCLReader in = server.getReader();
				BufferedMCLWriter out = server.getWriter();

				String error = in.waitForPrompt();
				if (error != null)
					throw new Exception(error);

				//			String query = "SET SCHEMA " + mapiSchema + ";'";
				//			if(TRACE) logger.trace("commit: SET SCHEMA query: " + query);
				//			out.write('s');
				//			out.write(query);
				//			out.newLine();
				//			
				//			// End the query.
				//			out.writeLine("");
				//			error = in.waitForPrompt();
				//			if (error != null)
				//				throw new Exception(error);

				// Set the number of records to copy in, + 10 so there is some buffer.
				// Using \N as a NULL value, requires '\\\\N' to evaluate to '\\N' for MonetDb to interpret it correctly.
				String query = "COPY "
						+ (dataRowList.size() + 10)
						+ " RECORDS INTO "
						+ tableName
						+ " FROM STDIN USING DELIMITERS '\\t','\\n' NULL AS '\\\\N';";
				if (TRACE)
					logger.trace("commit: query : " + query);

				// the leading 's' is essential, since it is a protocol
				// marker that should not be omitted, likewise the
				// trailing semicolon
				out.write('s');
				out.write(query);
				out.newLine();

				// Write all data rows.
				for (String dataRow : dataRowList) {
					if (TRACE)
						logger.trace("commit: Writing data row: " + dataRow
								+ " dataRow ends in newline: "
								+ dataRow.endsWith("\n"));
					// The dataRow is \n terminated, so no need to output newLine to output stream.
					out.write(dataRow);
				}

				out.writeLine(""); // need this one for synchronisation over flush()
				error = in.waitForPrompt();
				if (error != null)
					throw new Exception(error);
				out.writeLine(""); // server wants more, we're going to tell it, this is it
				error = in.waitForPrompt();
				if (error != null)
					throw new Exception(error);
				//			// disconnect from server
				//			server.close();
			} catch (IOException e) {
				logger.error("Unable to connect", e);
				throw new RuntimeException("Unable to connect", e);
			} catch (Throwable th) {
				logger.error("Commit error", th);

				// Do not pause replication for an error on tblips or tblurls, only for other tables.
				if (tableName.equalsIgnoreCase("tblips")
						|| tableName.equalsIgnoreCase("tblurls")) {
					logger.warn("Ignoring commit error for tableName: "
							+ tableName);
				} else if (th.getMessage().contains("PRIMARY KEY constraint")) {
					logger.warn("Commit error: PRIMARY KEY constraint, ignoring and continuing");
				} else {
					// Dump the rows to the error log.
					if (dataRowList != null && dataRowList.size() > 0) {
						StringBuilder sb = new StringBuilder();
						for (String dataRow : dataRowList) {
							sb.append(dataRow);
						}
						logger.error("Commit error: dumping rows in transaction: \n"
								+ sb.toString());
					}
					throw new RuntimeException("Commit error: tableName: "
							+ tableName, th);
				}
			} finally {
				try {
					if (server != null) {
						server.close();
						server = null;
					}
				} catch (Throwable th) {
					logger.error("Error closing MonetDb server connection", th);
				}
			}
			
			// Increment the insert counters.
			insertBatchCounter += 1;
			insertRowCounter += dataRowList.size();
			
			// Log stats.
	    	if(insertBatchCounter >= statsBatchLimit
	    			|| insertRowCounter >= statsRowLimit) {
	    		logStats();
	    	}

		}
		
    }
    
    /**
     * Build a tab-delimited row for the current table.
     * The CREATE TABLE for each table is included in the source code for reference.
     * All record objects for each table are initialized with the correct number of Field objects.
     * This method sets the value of each field, and outputs the record.
     * 
     * @param sqlStatement
     * @return
     */
    private String buildDataRow(DbsStatement sqlStatement) {

    	Record record = null;
    	Map<String,Integer> columnNameMap = null;

    	// Currently only INSERTs are used, so we can rely on the SQLStatement insertColumnNameList.
    	if(tableName.equalsIgnoreCase("player_stat")) {
    		record = playerStatRecord;
    		columnNameMap = playerStatColumnNameMap;
    	} else {
    		logger.warn("The table name is not supported. tableName: " + tableName);
    	}
    	
		// Reset the record.
		resetRecord(record);

		// Set all values on the record.
		for(int i=0;i<sqlStatement.getSymbolTable().getInsertUpdateColumnNameList().size();i++) {
			final String insertColumnName = sqlStatement.getSymbolTable().getInsertUpdateColumnNameList().get(i);
			Integer idx = columnNameMap.get(insertColumnName);
			if(idx == null) {
				logger.warn("The INSERT column name could not be found in the list. insertColumnName: " + insertColumnName);
				continue;
			}
			// Add the value.
			final Object value = sqlStatement.getValueList().get(i).getLiteralValue();
			if(value == null) {
				record.getField(idx).setNull();
			} else {
				record.getField(idx).setString(value.toString());
			}
		}
		
    	return record.toString();
    }

    /**
     * Log a stats INFO message when the batch or row counter reaches a certain size.
     */
    private void logStats() {
    	
    	long reportIntervalSeconds = (System.currentTimeMillis() - statsStartTime) > 1000 ? 
    			(System.currentTimeMillis() - statsStartTime) / 1000 : 1;
    	
    	// Message is in this format:
    	String message = "Stats: insertBatchCount: %d insertRowCount: %d "
    			+ "averageInsertBatchSize: %d "
    			+ "reportInterval: %ds insertRowsPerSecond: %d/s";
    	logger.info(String.format(message, insertBatchCounter, insertRowCounter,
    			(insertBatchCounter > 0 ? insertRowCounter / insertBatchCounter : 0),
    			reportIntervalSeconds, 
    			(insertRowCounter / reportIntervalSeconds)));
    	
    	// Reset all counters and start time.
    	statsStartTime = System.currentTimeMillis();
    	insertBatchCounter = 0;
    	insertRowCounter = 0;
    }
}
