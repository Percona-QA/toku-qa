package com.dbshards.examples.angryshards;

import com.codefutures.common.logging.Logger;
import com.codefutures.common.logging.LoggerFactory;
import com.codefutures.nio.NioServer;
import com.codefutures.nio.NioServerConfig;

/**
 * Copyright (C) 2011 CodeFutures Corporation. All rights reserved.
 */
public class AngryShardsServer {

    private static final Logger logger = LoggerFactory.getLogger(AngryShardsServer.class);

    public static void main(String[] args) {
        try {
            final NioServerConfig config = new NioServerConfig();
            config.setNumWorkerThreads(5);
            config.setUseWorkerThreadAffinity(true);
            NioServer server = new NioServer("AngryShards", 4444, config, new AngryShardsProtocolHandler());
            server.start();
            server.join();
        } catch (Throwable e) {
            logger.error("Server failed", e);
        }
    }
}
