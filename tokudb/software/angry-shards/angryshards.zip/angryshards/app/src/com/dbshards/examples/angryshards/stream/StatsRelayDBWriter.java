package com.dbshards.examples.angryshards.stream;

import com.codefutures.common.jdbc.ConnectionPool;
import com.codefutures.common.logging.Logger;
import com.codefutures.common.logging.LoggerFactory;
import com.dbshards.sqlparsernew.DbsStatement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.concurrent.*;

/**
 * This writer sends transactions to the log-only table on the MonetDb target cluster, in batches.
 * Each batch is a transaction, and is processed as a unit in a stream plugin in the target cluster.
 * 
 * Copyright (C) 2012 CodeFutures Corporation. All rights reserved.
 */
public class StatsRelayDBWriter {

    private static final Logger logger= LoggerFactory.getLogger(StatsRelayDBWriter.class);

    private static final boolean TRACE = logger.isTraceEnabled();
    private static final boolean DEBUG = logger.isDebugEnabled();

    private ConnectionPool connectionPool;

    private Connection conn;

    private int counter;

    private int targetBatchSize;
            
    // For this plugin, all statements for a single table go to a given pShard.
    private String targetShardHint;
    
    /**
     * Perform all actions on a single thread for now.
     */
    private final Executor exec = Executors.newSingleThreadExecutor();

    public StatsRelayDBWriter(final ConnectionPool connectionPool, final int targetBatchSize, final int targetPShardCount, DbsStatement initialSQLStatement) {
        this.connectionPool = connectionPool;
        this.targetBatchSize = targetBatchSize;
        
        // For this plugin, all statements for a single table go to a given pShard. Most tables are static.
        int sourcePShard = initialSQLStatement.getPrepareForExecuteOutput().getPshard();
        String tableName = initialSQLStatement.getTableList().get(0);
        int modResult = sourcePShard % targetPShardCount;
        int targetPShard = modResult == 0 ? targetPShardCount : modResult;
        
        // Build the shard hint.
        targetShardHint = "/*DBS_HINT: dbs_shard_action=shard_write, dbs_pshard=" + targetPShard + " */ ";
        logger.info("DBWriter: tableName: " + tableName + " targetShardHint: " + targetShardHint + " sourcePShard: " + sourcePShard 
        		+ " initialSQLStatement: " + initialSQLStatement);
     
    }

    public void execute(final DbsStatement sqlStatement) throws Exception {
        FutureTask<Object> task = new FutureTask<Object>(new Callable<Object>() {
            public Object call() throws Exception {
            	
                _execute(sqlStatement);
                return null;
            }
        });
        exec.execute(task);
        task.get();
    }

    private void _execute(final DbsStatement sqlStatement) throws Exception {

        for (int attempt=1 ; attempt<=2; attempt++) {
        	String sql = null;
            try {
                if (conn == null) {
                    logger.info("Getting connection from pool");
                    conn = connectionPool.borrowConnection();
                    logger.info("Got connection from pool OK");
                    conn.setAutoCommit(false);
                }

                sql = sqlStatement.getSQL();
                
                // Prepend each SQL statement with the shard hint. This ensures all writes go to a single shard, as shard-write.
                sql = targetShardHint + sql; 

                if (TRACE) logger.trace("Preparing Statement: " + sql);
                PreparedStatement pstmt = conn.prepareStatement(sql);
                if (sqlStatement.getValueList() != null) {
                    for (int i=0; i<sqlStatement.getValueList().size(); i++) {
                        final Object value = sqlStatement.getValueList().get(i).getLiteralValue();
                        if (TRACE) logger.trace("Binding param #" + (i + 1) + ": " + value);
                        pstmt.setObject(i+1, value);
                    }
                }

                if (TRACE) logger.trace("Executing ...");
                int rows = pstmt.executeUpdate();
                if (TRACE) logger.trace("Executed OK. " + rows + " row(s) updated.");

                pstmt.close();

                if (++counter >= targetBatchSize) {
                    // do the actual commit without using the executor
                    _commit();
                }

                // success! so we break out of the loop
                break;

            } catch (Throwable e) {
            	logger.error("Error executing SQL statement: sql: " + sql);
                handleDatabaseError(e);

                if (attempt == 2) {
                	if(conn != null) {
                		conn.rollback();
                	}
                    // escalate exception so that the stream agent pauses
                    throw new RuntimeException(e);
                }
            }
        }

    }

    public void commit() throws SQLException {
        FutureTask<Object> task = new FutureTask<Object>(new Callable<Object>() {
            public Object call() throws Exception {
                _commit();
                return null;
            }
        });
        exec.execute(task);
        try {
            task.get();
        } catch (Throwable e) {
            throw new RuntimeException("COMMIT failed", e);
        }
    }

    private synchronized void _commit() throws SQLException {
        if (conn != null && counter>0) {
            if (DEBUG) logger.debug("Committing batch of " + counter + " rows");
            try {
                conn.commit();
                counter = 0;
            } catch (Throwable e) {
                handleDatabaseError(e);
            }
        }
    }

    private void handleDatabaseError(final Throwable th) {
        logger.error("Error writing to database", th);
        try {
            if (conn != null) {
            	conn.rollback();
                connectionPool.returnConnection(conn);
            }
        } catch(SQLException sqle){
        	logger.error("Error rolling back after error", sqle);
        } finally {
            conn = null;
            counter = 0;
        }
    }

}
