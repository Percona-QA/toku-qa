package com.dbshards.examples.angryshards;

/**
 * Copyright (C) 2011 CodeFutures Corporation. All rights reserved.
 */
public interface AngryShardsService {

    //TODO:

}
