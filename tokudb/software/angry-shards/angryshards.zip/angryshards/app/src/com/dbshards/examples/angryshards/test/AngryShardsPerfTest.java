package com.dbshards.examples.angryshards.test;

import com.codefutures.common.jdbc.ConnectionPool;
import com.codefutures.common.jdbc.ConnectionPoolConfig;
import com.codefutures.common.jdbc.ConnectionPoolImpl;
import com.dbshards.examples.angryshards.service.AngryShardsService;
import org.jperf.PerfTest;
import org.jperf.PerfTestFactory;
import org.jperf.PerfTestRunner;

import java.io.File;
import java.io.FileInputStream;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Copyright (C) 2011 CodeFutures Corporation. All rights reserved.
 */
public class AngryShardsPerfTest implements PerfTest {

    public static void main(String[] args) throws Exception {

        if (args.length==0) {
            System.out.println("Usage: AngryShardsPerfTest [PROPERTIES-FILENAME]");
            System.exit(-1);
        }

        final File file = new File(args[0]);
        if (!file.exists()) {
            System.out.println("Failed to locate " + file.getAbsolutePath());
            System.exit(-1);
        }

        // read test properties
        Properties testProperties = new Properties();
        testProperties.load(new FileInputStream(file));

        final String jdbcDriver = getStringProperty(testProperties, "jdbc.driver", null);
        final String jdbcURL = getStringProperty(testProperties, "jdbc.url", null);
        final String jdbcUser = getStringProperty(testProperties, "jdbc.user", null);
        final String jdbcPassword = getStringProperty(testProperties, "jdbc.password", "");

        System.out.println("JDBC Driver : " + jdbcDriver);
        System.out.println("JDBC URL    : " + jdbcURL);
        System.out.println("JDBC User   : " + jdbcUser);

        if (jdbcDriver==null || jdbcURL==null || jdbcUser==null) {
            System.out.println("JDBC configuration error - NULL value(s)");
            System.exit(-1);
        }

        try {
            System.out.println("Initializing JDBC driver '" + jdbcDriver + "'");
            Class.forName(jdbcDriver).newInstance();
        } catch (Throwable e) {
            System.out.println("Failed to load JDBC driver '" + jdbcDriver + "' due to " + e.getClass() + ": " + e.getMessage());
            System.exit(-1);
        }

        // create connection pool
        final Properties jdbcProp = new Properties();
        jdbcProp.setProperty("user", jdbcUser);
        jdbcProp.setProperty("password", jdbcPassword);

        final ConnectionPoolConfig config = new ConnectionPoolConfig();
        config.setDriverClass(jdbcDriver);
        config.setUrl(jdbcURL);
        config.setProp(jdbcProp);
        config.setMaxConn(100); //TODO: make configurable

        ConnectionPool connectionPool = new ConnectionPoolImpl(config, "AngryShardsConnPool");

        System.out.println("Creating static data ...");

        // create service
        final AngryShardsService service = new AngryShardsService(connectionPool);

        // make sure the game exists
        final String gameName = "Angry Shards";
        int gameId = service.findGame(gameName);
        if (gameId==-1) {
            gameId = service.createGame(gameName);
        }
        final int _gameId = gameId;

        for (int i=0; i<5; i++) {
            final int statCode = 10 + i;
            service.createStatCode(statCode, "Statistic #" + statCode);
        }

        System.out.println("Running test ...");

        // run the test
        PerfTestRunner runner = new PerfTestRunner();
        runner.setMinThread(getIntProperty(testProperties, "min.thread", 1));
        runner.setMaxThread(getIntProperty(testProperties, "max.thread", 25));
        runner.setTestPeriod(getIntProperty(testProperties, "test.period", 500));
        runner.setStopThreadOnError(false);

        System.out.println("Min Thread  : " + runner.getMinThread());
        System.out.println("Max Thread  : " + runner.getMaxThread());
        System.out.println("Test Period : " + runner.getTestPeriod());

        runner.run(new PerfTestFactory() {
            @Override
            public PerfTest createPerfTest() throws Exception {
                return new AngryShardsPerfTest(service, _gameId);
            }
        });

        System.out.println("Done.");
        System.exit(0);
    }

    private static String getStringProperty(Properties prop, String name, String defaultValue) {
        String str = prop.getProperty(name);
        if (str==null || str.trim().length()==0) {
            return defaultValue;
        }
        return str;
    }

    private static int getIntProperty(Properties prop, String name, int defaultValue) {
        String str = prop.getProperty(name);
        if (str==null || str.trim().length()==0) {
            return defaultValue;
        }
        return Integer.parseInt(str);
    }

    private AngryShardsService service;

    private int gameId;

    public AngryShardsPerfTest(AngryShardsService service, int gameId) {
        this.service = service;
        this.gameId = gameId;
    }

    @Override
    public void setUp() throws Exception {
    }

    @Override
    public void test() throws Exception {

        try {
            // create a player
            final int num = (int) (Math.random() * 1000000);
            final String playerEmail = "player." + num + "@emailaddress.com";
            final String playerPassword = "secret123";
            final String playerScreenName = "player_" + num;

            // register
            service.registerPlayer(playerEmail, playerScreenName, playerPassword);

            // login
            int playerId = service.loginPlayer(playerEmail, playerPassword);

            // find an opponent
            int otherPlayerId = service.findRandomOpponent(playerId);

            // make up the game data
            int score[] = new int[3];
            for (int i=0; i<score.length; i++) {
                score[i] = (int) (Math.random() * 50);
            }

            // save the game
            int playerGameId = service.savePlayerGame(gameId, playerId, score);
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getClass() + ": " + e.getMessage());
        }

    }

    @Override
    public void tearDown() throws Exception {
    }
}
