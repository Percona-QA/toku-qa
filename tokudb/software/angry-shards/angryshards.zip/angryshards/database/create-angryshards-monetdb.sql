CREATE TABLE player_stat (
    player_stat_id BIGINT NOT NULL,
    stat_code SMALLINT NOT NULL,
    stat_value INTEGER NOT NULL,
    stat_timestamp TIMESTAMP NOT NULL,
    player_id BIGINT,
    PRIMARY KEY (player_stat_id)
);