# ---------------------------------------------------------------------- #
# Script generated with: DeZign for Databases v6.3.0                     #
# Target DBMS:           MySQL 5                                         #
# Project file:          angryshards.dez                                 #
# Project name:                                                          #
# Author:                                                                #
# Script type:           Database creation script                        #
# Created on:            2012-07-15 12:20                                #
# ---------------------------------------------------------------------- #


# ---------------------------------------------------------------------- #
# Tables                                                                 #
# ---------------------------------------------------------------------- #

# ---------------------------------------------------------------------- #
# Add table "player"                                                     #
# ---------------------------------------------------------------------- #

CREATE TABLE `player` (
    `player_id` BIGINT NOT NULL AUTO_INCREMENT,
    `player_email` VARCHAR(100),
    `screen_name` VARCHAR(40),
    `player_balance` INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT `PK_player` PRIMARY KEY (`player_id`)
);

# ---------------------------------------------------------------------- #
# Add table "player_auth"                                                #
# ---------------------------------------------------------------------- #

CREATE TABLE `player_auth` (
    `player_auth_id` BIGINT NOT NULL AUTO_INCREMENT,
    `auth_type_code` SMALLINT NOT NULL,
    `auth_id` VARCHAR(100) NOT NULL,
    `password` VARCHAR(40),
    `player_id` BIGINT,
    CONSTRAINT `PK_player_auth` PRIMARY KEY (`player_auth_id`)
);

# ---------------------------------------------------------------------- #
# Add table "game"                                                       #
# ---------------------------------------------------------------------- #

CREATE TABLE `game` (
    `game_id` INTEGER NOT NULL AUTO_INCREMENT,
    `game_name` VARCHAR(100) NOT NULL,
    `game_description` VARCHAR(16384),
    `status_code` SMALLINT NOT NULL DEFAULT 10,
    CONSTRAINT `PK_game` PRIMARY KEY (`game_id`)
) COMMENT = 'A game is a unique type of game. Initially there is only a single game, Angry Shards.';

# ---------------------------------------------------------------------- #
# Add table "code"                                                       #
# ---------------------------------------------------------------------- #

CREATE TABLE `code` (
    `code_id` INTEGER NOT NULL AUTO_INCREMENT,
    `table_name` VARCHAR(255) NOT NULL,
    `column_name` VARCHAR(255) NOT NULL,
    `code_value` SMALLINT NOT NULL,
    `code_name` VARCHAR(40) NOT NULL,
    `code_description` VARCHAR(1024),
    CONSTRAINT `PK_code` PRIMARY KEY (`code_id`)
) COMMENT = 'A generic table of code values, using table_name and column_name to uniquely identify a particular code type.';

# ---------------------------------------------------------------------- #
# Add table "player_game"                                                #
# ---------------------------------------------------------------------- #

CREATE TABLE `player_game` (
    `player_game_id` BIGINT NOT NULL AUTO_INCREMENT,
    `player_id` BIGINT NOT NULL,
    `type_code` SMALLINT,
    `status_code` SMALLINT,
    `game_start` BIGINT,
    `game_end` BIGINT,
    `player_score` INTEGER NOT NULL DEFAULT 0,
    `game_id` INTEGER,
    CONSTRAINT `PK_player_game` PRIMARY KEY (`player_game_id`)
);

# ---------------------------------------------------------------------- #
# Add table "game_component"                                             #
# ---------------------------------------------------------------------- #

CREATE TABLE `game_component` (
    `game_component_id` INTEGER NOT NULL AUTO_INCREMENT,
    `game_component_name` VARCHAR(60) NOT NULL,
    `game_component_description` VARCHAR(1024),
    `type_code` SMALLINT NOT NULL,
    `status_code` SMALLINT NOT NULL,
    `cost` INTEGER NOT NULL DEFAULT 0,
    `game_id` INTEGER,
    CONSTRAINT `PK_game_component` PRIMARY KEY (`game_component_id`)
);

# ---------------------------------------------------------------------- #
# Add table "player_game_component"                                      #
# ---------------------------------------------------------------------- #

CREATE TABLE `player_game_component` (
    `player_game_component_id` BIGINT NOT NULL AUTO_INCREMENT,
    `cost` INTEGER NOT NULL DEFAULT 0,
    `game_component_id` INTEGER,
    `player_id` BIGINT,
    CONSTRAINT `PK_player_game_component` PRIMARY KEY (`player_game_component_id`)
);

# ---------------------------------------------------------------------- #
# Add table "player_transaction"                                         #
# ---------------------------------------------------------------------- #

CREATE TABLE `player_transaction` (
    `player_transaction_id` BIGINT NOT NULL AUTO_INCREMENT,
    `type_code` SMALLINT NOT NULL,
    `status_code` SMALLINT NOT NULL,
    `amount` INTEGER NOT NULL DEFAULT 0,
    `player_id` BIGINT,
    CONSTRAINT `PK_player_transaction` PRIMARY KEY (`player_transaction_id`)
);

# ---------------------------------------------------------------------- #
# Add table "player_lookup"                                              #
# ---------------------------------------------------------------------- #

CREATE TABLE `player_lookup` (
    `player_lookup_id` BIGINT NOT NULL DEFAULT 0 AUTO_INCREMENT,
    `auth_id` VARCHAR(100) NOT NULL,
    `player_id` BIGINT NOT NULL,
    `player_auth_id` BIGINT NOT NULL,
    CONSTRAINT `PK_player_lookup` PRIMARY KEY (`player_lookup_id`)
);

# ---------------------------------------------------------------------- #
# Add table "game_score_amount"                                          #
# ---------------------------------------------------------------------- #

CREATE TABLE `game_score_amount` (
    `game_score_amount_id` INTEGER NOT NULL AUTO_INCREMENT,
    `score_from` INTEGER NOT NULL DEFAULT 0,
    `score_to` INTEGER NOT NULL DEFAULT 0,
    `amount` INTEGER NOT NULL DEFAULT 0,
    `game_id` INTEGER,
    CONSTRAINT `PK_game_score_amount` PRIMARY KEY (`game_score_amount_id`)
);

# ---------------------------------------------------------------------- #
# Add table "player_friend"                                              #
# ---------------------------------------------------------------------- #

CREATE TABLE `player_friend` (
    `player_friend_id` BIGINT NOT NULL AUTO_INCREMENT,
    `player_id` BIGINT NOT NULL,
    `friend_id` BIGINT NOT NULL,
    `type_code` SMALLINT NOT NULL,
    `status_code` SMALLINT NOT NULL,
    `invite_message` VARCHAR(1024),
    CONSTRAINT `PK_player_friend` PRIMARY KEY (`player_friend_id`)
);

# ---------------------------------------------------------------------- #
# Add table "leader_board"                                               #
# ---------------------------------------------------------------------- #

CREATE TABLE `leader_board` (
    `leader_board_id` BIGINT NOT NULL AUTO_INCREMENT,
    `player_id` BIGINT NOT NULL,
    `score` INTEGER NOT NULL,
    CONSTRAINT `PK_leader_board` PRIMARY KEY (`leader_board_id`)
);

# ---------------------------------------------------------------------- #
# Add table "player_game_opponent"                                       #
# ---------------------------------------------------------------------- #

CREATE TABLE `player_game_opponent` (
    `player_game_opponent_id` BIGINT NOT NULL AUTO_INCREMENT,
    `opponent_player_id` BIGINT NOT NULL,
    `opponent_screen_name` VARCHAR(40) NOT NULL,
    `challenge_message` VARCHAR(1024),
    `opponent_score` INTEGER NOT NULL DEFAULT 0,
    `status_code` SMALLINT NOT NULL,
    `player_game_id` BIGINT,
    `player_friend_id` BIGINT,
    CONSTRAINT `PK_player_game_opponent` PRIMARY KEY (`player_game_opponent_id`)
);

# ---------------------------------------------------------------------- #
# Add table "stat_code"                                                  #
# ---------------------------------------------------------------------- #

CREATE TABLE `stat_code` (
    `stat_code` SMALLINT NOT NULL,
    `stat_name` VARCHAR(60) NOT NULL,
    `stat_description` VARCHAR(1024),
    CONSTRAINT `PK_stat_code` PRIMARY KEY (`stat_code`)
);

# ---------------------------------------------------------------------- #
# Add table "player_stat"                                                #
# ---------------------------------------------------------------------- #

CREATE TABLE `player_stat` (
    `player_stat_id` BIGINT NOT NULL AUTO_INCREMENT,
    `stat_code` SMALLINT NOT NULL,
    `stat_value` INTEGER NOT NULL,
    `stat_timestamp` TIMESTAMP NOT NULL,
    `player_id` BIGINT,
    CONSTRAINT `PK_player_stat` PRIMARY KEY (`player_stat_id`)
);

# ---------------------------------------------------------------------- #
# Add table "player_game_round"                                          #
# ---------------------------------------------------------------------- #

CREATE TABLE `player_game_round` (
    `player_game_round_id` BIGINT NOT NULL AUTO_INCREMENT,
    `player_score` INTEGER NOT NULL,
    `player_id` BIGINT NOT NULL,
    `player_game_id` BIGINT,
    CONSTRAINT `PK_player_game_round` PRIMARY KEY (`player_game_round_id`)
);

# ---------------------------------------------------------------------- #
# Foreign key constraints                                                #
# ---------------------------------------------------------------------- #

ALTER TABLE `player_auth` ADD CONSTRAINT `player_player_auth` 
    FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`);

ALTER TABLE `player_game` ADD CONSTRAINT `player_player_game` 
    FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`);

ALTER TABLE `player_game` ADD CONSTRAINT `game_player_game` 
    FOREIGN KEY (`game_id`) REFERENCES `game` (`game_id`);

ALTER TABLE `game_component` ADD CONSTRAINT `game_game_component` 
    FOREIGN KEY (`game_id`) REFERENCES `game` (`game_id`);

ALTER TABLE `player_game_component` ADD CONSTRAINT `game_component_player_game_component` 
    FOREIGN KEY (`game_component_id`) REFERENCES `game_component` (`game_component_id`);

ALTER TABLE `player_game_component` ADD CONSTRAINT `player_player_game_component` 
    FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`);

ALTER TABLE `player_transaction` ADD CONSTRAINT `player_player_transaction` 
    FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`);

ALTER TABLE `game_score_amount` ADD CONSTRAINT `game_game_score_amount` 
    FOREIGN KEY (`game_id`) REFERENCES `game` (`game_id`);

ALTER TABLE `player_friend` ADD CONSTRAINT `player_player_friend` 
    FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`);

ALTER TABLE `player_game_opponent` ADD CONSTRAINT `player_friend_player_game_opponent` 
    FOREIGN KEY (`player_friend_id`) REFERENCES `player_friend` (`player_friend_id`);

ALTER TABLE `player_game_opponent` ADD CONSTRAINT `player_game_player_game_opponent` 
    FOREIGN KEY (`player_game_id`) REFERENCES `player_game` (`player_game_id`);

ALTER TABLE `player_stat` ADD CONSTRAINT `player_player_stat` 
    FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`);

ALTER TABLE `player_stat` ADD CONSTRAINT `stat_code_player_stat` 
    FOREIGN KEY (`stat_code`) REFERENCES `stat_code` (`stat_code`);

ALTER TABLE `player_game_round` ADD CONSTRAINT `player_game_player_game_round` 
    FOREIGN KEY (`player_game_id`) REFERENCES `player_game` (`player_game_id`);
