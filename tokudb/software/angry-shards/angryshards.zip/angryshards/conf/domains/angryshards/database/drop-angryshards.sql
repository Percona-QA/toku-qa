# ---------------------------------------------------------------------- #
# Script generated with: DeZign for Databases v6.3.0                     #
# Target DBMS:           MySQL 5                                         #
# Project file:          angryshards.dez                                 #
# Project name:                                                          #
# Author:                                                                #
# Script type:           Database drop script                            #
# Created on:            2012-07-15 12:20                                #
# ---------------------------------------------------------------------- #


# ---------------------------------------------------------------------- #
# Drop foreign key constraints                                           #
# ---------------------------------------------------------------------- #

ALTER TABLE `player_auth` DROP FOREIGN KEY `player_player_auth`;

ALTER TABLE `player_game` DROP FOREIGN KEY `player_player_game`;

ALTER TABLE `player_game` DROP FOREIGN KEY `game_player_game`;

ALTER TABLE `game_component` DROP FOREIGN KEY `game_game_component`;

ALTER TABLE `player_game_component` DROP FOREIGN KEY `game_component_player_game_component`;

ALTER TABLE `player_game_component` DROP FOREIGN KEY `player_player_game_component`;

ALTER TABLE `player_transaction` DROP FOREIGN KEY `player_player_transaction`;

ALTER TABLE `game_score_amount` DROP FOREIGN KEY `game_game_score_amount`;

ALTER TABLE `player_friend` DROP FOREIGN KEY `player_player_friend`;

ALTER TABLE `player_game_opponent` DROP FOREIGN KEY `player_friend_player_game_opponent`;

ALTER TABLE `player_game_opponent` DROP FOREIGN KEY `player_game_player_game_opponent`;

ALTER TABLE `player_stat` DROP FOREIGN KEY `player_player_stat`;

ALTER TABLE `player_stat` DROP FOREIGN KEY `stat_code_player_stat`;

ALTER TABLE `player_game_round` DROP FOREIGN KEY `player_game_player_game_round`;

# ---------------------------------------------------------------------- #
# Drop table "player_game_round"                                         #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `player_game_round` MODIFY `player_game_round_id` BIGINT NOT NULL;

# Drop constraints #

ALTER TABLE `player_game_round` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `player_game_round`;

# ---------------------------------------------------------------------- #
# Drop table "player_stat"                                               #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `player_stat` MODIFY `player_stat_id` BIGINT NOT NULL;

# Drop constraints #

ALTER TABLE `player_stat` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `player_stat`;

# ---------------------------------------------------------------------- #
# Drop table "stat_code"                                                 #
# ---------------------------------------------------------------------- #

# Drop constraints #

ALTER TABLE `stat_code` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `stat_code`;

# ---------------------------------------------------------------------- #
# Drop table "player_game_opponent"                                      #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `player_game_opponent` MODIFY `player_game_opponent_id` BIGINT NOT NULL;

# Drop constraints #

ALTER TABLE `player_game_opponent` ALTER COLUMN `opponent_score` DROP DEFAULT;

ALTER TABLE `player_game_opponent` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `player_game_opponent`;

# ---------------------------------------------------------------------- #
# Drop table "leader_board"                                              #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `leader_board` MODIFY `leader_board_id` BIGINT NOT NULL;

# Drop constraints #

ALTER TABLE `leader_board` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `leader_board`;

# ---------------------------------------------------------------------- #
# Drop table "player_friend"                                             #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `player_friend` MODIFY `player_friend_id` BIGINT NOT NULL;

# Drop constraints #

ALTER TABLE `player_friend` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `player_friend`;

# ---------------------------------------------------------------------- #
# Drop table "game_score_amount"                                         #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `game_score_amount` MODIFY `game_score_amount_id` INTEGER NOT NULL;

# Drop constraints #

ALTER TABLE `game_score_amount` ALTER COLUMN `score_from` DROP DEFAULT;

ALTER TABLE `game_score_amount` ALTER COLUMN `score_to` DROP DEFAULT;

ALTER TABLE `game_score_amount` ALTER COLUMN `amount` DROP DEFAULT;

ALTER TABLE `game_score_amount` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `game_score_amount`;

# ---------------------------------------------------------------------- #
# Drop table "player_lookup"                                             #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `player_lookup` MODIFY `player_lookup_id` BIGINT NOT NULL DEFAULT 0;

# Drop constraints #

ALTER TABLE `player_lookup` ALTER COLUMN `player_lookup_id` DROP DEFAULT;

ALTER TABLE `player_lookup` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `player_lookup`;

# ---------------------------------------------------------------------- #
# Drop table "player_transaction"                                        #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `player_transaction` MODIFY `player_transaction_id` BIGINT NOT NULL;

# Drop constraints #

ALTER TABLE `player_transaction` ALTER COLUMN `amount` DROP DEFAULT;

ALTER TABLE `player_transaction` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `player_transaction`;

# ---------------------------------------------------------------------- #
# Drop table "player_game_component"                                     #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `player_game_component` MODIFY `player_game_component_id` BIGINT NOT NULL;

# Drop constraints #

ALTER TABLE `player_game_component` ALTER COLUMN `cost` DROP DEFAULT;

ALTER TABLE `player_game_component` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `player_game_component`;

# ---------------------------------------------------------------------- #
# Drop table "game_component"                                            #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `game_component` MODIFY `game_component_id` INTEGER NOT NULL;

# Drop constraints #

ALTER TABLE `game_component` ALTER COLUMN `cost` DROP DEFAULT;

ALTER TABLE `game_component` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `game_component`;

# ---------------------------------------------------------------------- #
# Drop table "player_game"                                               #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `player_game` MODIFY `player_game_id` BIGINT NOT NULL;

# Drop constraints #

ALTER TABLE `player_game` ALTER COLUMN `player_score` DROP DEFAULT;

ALTER TABLE `player_game` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `player_game`;

# ---------------------------------------------------------------------- #
# Drop table "code"                                                      #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `code` MODIFY `code_id` INTEGER NOT NULL;

# Drop constraints #

ALTER TABLE `code` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `code`;

# ---------------------------------------------------------------------- #
# Drop table "game"                                                      #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `game` MODIFY `game_id` INTEGER NOT NULL;

# Drop constraints #

ALTER TABLE `game` ALTER COLUMN `status_code` DROP DEFAULT;

ALTER TABLE `game` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `game`;

# ---------------------------------------------------------------------- #
# Drop table "player_auth"                                               #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `player_auth` MODIFY `player_auth_id` BIGINT NOT NULL;

# Drop constraints #

ALTER TABLE `player_auth` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `player_auth`;

# ---------------------------------------------------------------------- #
# Drop table "player"                                                    #
# ---------------------------------------------------------------------- #

# Remove autoinc for PK drop #

ALTER TABLE `player` MODIFY `player_id` BIGINT NOT NULL;

# Drop constraints #

ALTER TABLE `player` ALTER COLUMN `player_balance` DROP DEFAULT;

ALTER TABLE `player` DROP PRIMARY KEY;

# Drop table #

DROP TABLE `player`;
