#!/bin/sh

ant clean default run
