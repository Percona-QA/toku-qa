#!/bin/sh

ant clean default $1
